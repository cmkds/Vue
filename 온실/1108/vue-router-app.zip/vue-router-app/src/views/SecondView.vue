<template>
  <div>
    <h1>두 번째 페이지입니다</h1>
  </div>
</template>

<script>
export default {
  name:'SecondView',

}
</script>

<style>

</style>