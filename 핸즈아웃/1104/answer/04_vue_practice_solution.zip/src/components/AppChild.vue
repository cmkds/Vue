<template>
  <div id="child">
    <h2>AppChild</h2>
    <input type="text" :value="childData" @input="onChildInputChange">
    <p>appData: {{ appData }}</p>
    <p>parentData: {{ parentData }}</p>
  </div>
</template>

<script>
export default {
  name: 'AppChild',
  props: {
    appData: {
      type: String,
    },
    parentData: {
      type: String,
    },
    childData: {
      type: String,
    },
  },
  methods: {
    onChildInputChange: function (event) {
      this.$emit('child-input-change', event.target.value)
    }
  },
}
</script>
<style>
#child {
  width: 500px;
  margin: 0 auto;
  border: 1px solid blue;
}
</style>