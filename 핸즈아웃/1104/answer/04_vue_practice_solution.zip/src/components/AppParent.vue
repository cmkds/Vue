<template>
  <div id="parent">
    <h2>AppParent</h2>
    <input type="text" :value="parentData" @input="onParentInputChange">
    <p>appData: {{ appData }}</p>
    <p>childData: {{ childData }}</p>
    <AppChild
      :app-data="appData"
      :parent-data="parentData"
      :child-data="childData"
      @child-input-change="onChildInputChange" />
  </div>
</template>

<script>
import AppChild from './AppChild'

export default {
  name: 'AppParent',
  components: {
    AppChild,
  },
  props: {
    appData: {
      type: String,
    },
    parentData: {
      type: String,
    },
    childData: {
      type: String,
    },
  },
  methods: {
    onParentInputChange: function (event) {
      this.$emit('parent-input-change', event.target.value)
    },
    onChildInputChange: function (childInputData) {
      this.$emit('child-input-change', childInputData)
    }
  },

}
</script>
<style>
#parent {
  width: 500px;
  margin: 0 auto;
  border: 1px solid red;
}
</style>