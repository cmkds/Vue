<template>
  <div id="app">
    <h2>App</h2>
    <input type="text" v-model="appData">
    <p>parentData: {{ parentData }}</p>
    <p>childData: {{ childData }}</p>
    <AppParent
      :app-data="appData"
      :parent-data="parentData"
      :child-data="childData"
      @parent-input-change="onParentInputChange"
      @child-input-change="onInputChildChange" />
  </div>
</template>

<script>
import AppParent from './components/AppParent.vue'

export default {
  name: 'App',
  components: {
    AppParent,
  },
  data: function () {
    return {
      appData: null,
      parentData: null,
      childData: null,
    }
  },
  methods: {
    onParentInputChange: function (parentInputData) { 
      this.parentData = parentInputData
    },
    onInputChildChange: function (childInputChange) {
      this.childData = childInputChange
    }
  },
}
</script>
<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;

  /* 추가 */
  width: 500px;
  margin: 0 auto;
  border: 1px solid black;
}
</style>